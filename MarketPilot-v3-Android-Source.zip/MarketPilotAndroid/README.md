# MarketPilot — Android source project (v3.0 development build)

An Android WebView application built around the uploaded `day-trader-skill-main` toolkit. It provides a mobile multi-market quote dashboard, technical indicator snapshot, SMC structure/sweep/FVG heuristics, approximate support/resistance, candle-volume price buckets, rule-based composite signal assessment, local watchlist and risk/position-size calculator, OHLC candlestick charts with optional EMA 20/50 overlays, six chart timeframes (1D, 5D, 1M, 3M, 6M, 1Y), ATR-based illustrative planning levels, external market research links, and optional 60-second quote refresh while the app is open. Price alerts are checked on manual or enabled foreground refresh and can raise an Android local notification (permission required).

## What is reused from the uploaded ZIP

The original Python modules are preserved in `source_toolkit/` with their MIT license and are included for reference and future backend integration. MarketPilot's first Android build reimplements a small subset of the toolkit's user-facing workflow in the mobile UI:

- Technical chart/indicator review inspired by `trader-scanner/scan.py` and `trader-entry/entry.py`.
- Risk budget and unit sizing inspired by `trader-budget/size.py` and `trader-risk/check.py`.
- Price history retrieval uses the Yahoo Finance chart endpoint, as the original toolkit does.

The original Python scripts are not directly executable inside this Android UI. Their scanner, SEC news/earnings, congressional disclosure, alert scheduler, backtesting/time-machine and broker connector workflows have not yet been ported to Android.

## Build the Android app

### Build an APK online without Android Studio

The repository includes `.github/workflows/android-apk.yml`. Push this project to a GitHub repository, then open **Actions → Build MarketPilot APK → Run workflow**. When the workflow succeeds, download the `MarketPilot-v3-debug-apk` artifact and install the APK on your Android device. The workflow builds a debug APK; it is not a Play Store release-signed package.


1. Install Android Studio (current stable) and its Android SDK Platform 35.
2. Open this `MarketPilotAndroid` folder in Android Studio.
3. Allow Gradle sync to complete. The project uses Android Gradle Plugin 8.7.3.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**. To create an installable package, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The generated debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Supported symbol examples

- US equities: `AAPL`, `MSFT`, `TSLA`
- Index: `^GSPC`
- Gold futures: `GC=F`
- Crude oil futures: `CL=F`
- FX: `EURUSD=X`
- Crypto: `BTC-USD`

Use Yahoo Finance ticker syntax. Availability varies by instrument and provider. This is not a broker feed and quotes can be delayed, incomplete, rate-limited or unavailable.

## Version 3 analysis notes

- BOS/CHoCH and liquidity sweeps use confirmed two-candle swing pivots from the currently loaded OHLC bars. They are rule-based approximations, not institutional order-flow data.
- Fair Value Gaps use the common three-candle high/low gap definition and display the most recent detected gap.
- Support/resistance uses the nearest confirmed swing low/high around the current price; it is not a zone-clustering engine.
- Volume Profile allocates each candle's reported volume to a single typical-price bucket. It is an approximation, not exchange-level volume-at-price or bid/ask delta. If the provider does not supply meaningful volume, the profile is unavailable.
- The composite BUY/SELL/WAIT score combines the existing EMA/RSI/MACD checks with a capped SMC contribution. The displayed alignment score is not a win probability and has not been validated by out-of-sample backtesting.
- Android notifications in this source build are on-device local notifications emitted when the app detects an alert during manual or enabled foreground refresh. This is not remote push delivery or guaranteed background monitoring. Remote push requires a Firebase project, app configuration and a trusted server/market-data alert service.

## Important limitations

- Signals are simple EMA(20/50), RSI(14) and MACD-histogram alignment rules; they are not a tested predictive model and do not estimate win probability.
- Chart timeframes: 1D (1-minute bars), 5D (5-minute bars), 1M (30-minute bars), 3M and 6M (daily bars), and 1Y (weekly bars). Optional EMA 20/50 overlays can be toggled on the chart. The app renders OHLC candlesticks. Provider interval availability can vary by symbol.
- The risk calculator reports indicative units from account risk and stop distance. It does not calculate contract multipliers, pip value, margin, fees, slippage, or currency conversion. Do not use its unit output directly for leveraged FX/CFD/futures orders.
- No broker integration, order placement, remote push service, background price polling, or automated trading is included. Optional 60-second refresh and price-alert checks run only while the app is open and visible; local notifications are generated only when a check runs. Market news and the economic calendar open external websites rather than providing an in-app verified feed.
- Yahoo Finance's public chart endpoint is unofficial and may change or block requests.
- No API keys or brokerage credentials are requested or stored.

## Safety

Educational tool only, not financial advice. Always verify quotes and contract specifications with your broker. Never treat a generated signal as an instruction to trade. Start with paper trading and risk only money you can afford to lose.
