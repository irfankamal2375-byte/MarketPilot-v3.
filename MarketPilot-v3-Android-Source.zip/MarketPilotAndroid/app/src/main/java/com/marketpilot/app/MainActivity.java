package com.marketpilot.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;
    private static final String ALERT_CHANNEL = "marketpilot_alerts";
    private static final int REQUEST_POST_NOTIFICATIONS = 902;
    private String pendingAlertTitle;
    private String pendingAlertBody;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        createAlertChannel();
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new MarketBridge(), "MarketBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private void createAlertChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(ALERT_CHANNEL, "MarketPilot price alerts", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("On-device notifications when a watched price alert is detected while MarketPilot is checking data.");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    private void postLocalAlert(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            pendingAlertTitle = title;
            pendingAlertBody = body;
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQUEST_POST_NOTIFICATIONS);
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pending = launch == null ? null : PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, ALERT_CHANNEL)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true);
        if (pending != null) builder.setContentIntent(pending);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingAlertTitle != null) {
            postLocalAlert(pendingAlertTitle, pendingAlertBody);
            pendingAlertTitle = null;
            pendingAlertBody = null;
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    public class MarketBridge {
        @JavascriptInterface public void notifyAlert(String title, String body) {
            final String safeTitle = title == null ? "MarketPilot alert" : title.substring(0, Math.min(title.length(), 80));
            final String safeBody = body == null ? "A saved price alert was triggered." : body.substring(0, Math.min(body.length(), 180));
            runOnUiThread(() -> postLocalAlert(safeTitle, safeBody));
        }
        @JavascriptInterface public String quote(String symbol, String range, String interval) {
            HttpURLConnection c = null;
            try {
                String safe = symbol.trim().replace(" ", "");
                if (!safe.matches("[A-Za-z0-9^=._-]{1,32}")) return error("Invalid symbol");
                String r = range.matches("1d|5d|1mo|3mo|6mo|1y") ? range : "5d";
                String i = interval.matches("1m|2m|5m|15m|30m|60m|1d|1wk") ? interval : "5m";
                URL u = new URL("https://query1.finance.yahoo.com/v8/finance/chart/" + safe + "?range=" + r + "&interval=" + i + "&includePrePost=true");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(15000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 MarketPilot/2.0");
                int status = c.getResponseCode();
                BufferedReader br = new BufferedReader(new InputStreamReader(status >= 400 ? c.getErrorStream() : c.getInputStream()));
                StringBuilder body = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) body.append(line); br.close();
                if (status >= 400) return error("Market data provider returned HTTP " + status);
                JSONObject root = new JSONObject(body.toString());
                JSONObject result = root.getJSONObject("chart").getJSONArray("result").getJSONObject(0);
                JSONObject meta = result.getJSONObject("meta");
                JSONArray ts = result.optJSONArray("timestamp");
                JSONObject quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
                JSONArray opens = quote.optJSONArray("open"), closes = quote.optJSONArray("close"), highs = quote.optJSONArray("high"), lows = quote.optJSONArray("low"), volumes = quote.optJSONArray("volume");
                JSONArray rows = new JSONArray();
                if (ts != null && closes != null) for (int x=0; x<ts.length(); x++) {
                    if (closes.isNull(x)) continue;
                    JSONObject row = new JSONObject(); row.put("t", ts.optLong(x)); row.put("o", opens == null || opens.isNull(x) ? closes.optDouble(x) : opens.optDouble(x)); row.put("c", closes.optDouble(x));
                    row.put("h", highs == null || highs.isNull(x) ? closes.optDouble(x) : highs.optDouble(x));
                    row.put("l", lows == null || lows.isNull(x) ? closes.optDouble(x) : lows.optDouble(x));
                    row.put("v", volumes == null || volumes.isNull(x) ? 0 : volumes.optDouble(x)); rows.put(row);
                }
                JSONObject out = new JSONObject(); out.put("ok", true); out.put("symbol", safe);
                out.put("name", meta.optString("longName", meta.optString("shortName", safe)));
                out.put("currency", meta.optString("currency", "")); out.put("exchange", meta.optString("exchangeName", ""));
                out.put("price", meta.optDouble("regularMarketPrice", rows.length() == 0 ? 0 : rows.getJSONObject(rows.length()-1).optDouble("c")));
                out.put("previousClose", meta.optDouble("chartPreviousClose", meta.optDouble("previousClose", 0)));
                out.put("marketState", meta.optString("marketState", "")); out.put("rows", rows);
                return out.toString();
            } catch (Exception e) { return error("Could not load quote: " + e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        }
        private String error(String message) { try { JSONObject o = new JSONObject(); o.put("ok", false); o.put("error", message); return o.toString(); } catch(Exception e) { return "{\"ok\":false}"; } }
    }
}
