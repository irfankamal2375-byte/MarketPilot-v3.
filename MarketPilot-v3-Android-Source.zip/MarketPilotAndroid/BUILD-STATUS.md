# MarketPilot v3 build status

## Completed in this source package

- Preserved the existing Android Java/WebView application and bundled Day Trader Skill source toolkit.
- Updated Android app version metadata to 3.0.0.
- Added candle-based BOS/CHoCH, liquidity-sweep and three-candle FVG heuristics.
- Added nearest confirmed swing support/resistance estimates.
- Added an approximate candle-volume price-bucket profile with POC and visual relative-volume bars.
- Added a capped SMC contribution to the existing EMA/RSI/MACD BUY/SELL/WAIT rule score.
- Added Android on-device local notification support for price alerts, including Android 13+ notification permission handling.
- Added a GitHub Actions workflow that can build a debug APK online without Android Studio.

## Validation performed

- JavaScript syntax check: passed with Node.js.
- Synthetic OHLC smoke test for SMC and volume profile: passed.
- Android manifest XML parse: passed.
- Original Python toolkit test suite: 315 tests passed.

## APK status: not built in this environment

This execution environment does not contain Gradle, Android SDK/build-tools, or an Android platform `android.jar`, and outbound package downloads are unavailable. Therefore no APK has been compiled or device-tested here. Do not treat this source ZIP as an installable APK.

To obtain the APK without installing Android Studio, create a GitHub repository using the contents of this `MarketPilotAndroid` folder as the repository root (including `.github/workflows/android-apk.yml`), push the files, then run **Actions → Build MarketPilot APK → Run workflow**. Download the `MarketPilot-v3-debug-apk` artifact after the workflow succeeds.

## Known scope limits

- Market quotes still use Yahoo Finance's unofficial public chart endpoint. Feed availability, timing, and completeness vary; timing is not guaranteed real-time.
- The new SMC and Volume Profile functions are candle-derived heuristics, not institutional order-book/order-flow analysis.
- Local notifications are emitted only when the app is actively checking the saved alert. Background monitoring and remote Firebase push delivery are not configured.
- No broker login, order placement, automated trading, or guaranteed-profit prediction is included.
